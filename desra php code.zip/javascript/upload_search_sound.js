function is_array(input){
    return typeof(input)=='object'&&(input instanceof Array);
}
vals = new Array();
a = '4';
function addInput(){

    ret = "<input type=\"text\" id=\"keyword_"+ a +"\"";
    ret +=" name=\"keyword[]\"  /><br>"; 
    ih = document.getElementById('add_keywords').innerHTML;
    ih += ret;
    document.getElementById('add_keywords').innerHTML = ih;  
    a++;

}

function addInputs(){
    inputs_num = document.getElementById('add_inputs_num').value;
    ret = "";
    for(i = 1; i <= inputs_num; i++){    
        ret += "<input type=\"text\" id=\"keyword_"+ (i+3) +"\"";
        ret +=" name=\"keyword[]\"  /><br>"; 
    }
    document.getElementById('add_keywords').innerHTML = ret;  
    


}
