function validateApproval(){
    errors = "";
    el = document.getElementById("approval");
    if(! el.checked){
        errors +="Please check box to approve the terms and conditions\n";
    }
     el = document.getElementById("txtGuess");      
    if(! el.value > 0){
      errors += "Please copy the letters in the graphic image\n"
    }
    if(errors.length){
       alert(errors);
       return false;
    } else {
      return true
    }
}
function validateLogin(){
    errors = "";
    el = document.getElementById('username');
    if(el.value.length > 0){
    } else {
        errors += "Please fill in your username\n";
        return false;
    }
    el = document.getElementById('password');
    if(el.value.length > 0){
    } else {
        errors += "Please fill in your password\n";
        return false;
    }     
}

function validateHearingQuestionaire(){
    errors = "";
    inputs = document.getElementsByTagName('input');
    country = document.getElementById('country');
    len = inputs.length;
    var has_gender = false;
    var has_age = false;
    var has_native_language = false;
    var has_primary_language = false;
    var has_country = false;
    for(var i = 0; i < len;i++ ){
        switch (inputs[i].type){
            case 'radio':
                switch (inputs[i].name){
                    case 'gender':
                        if(inputs[i].checked){
                            has_gender = true;
                        }
                    break;
                    case 'hearing_loss':
                    break;
                    case 'symmetry':
                    break;
                }
             case 'text':
                switch (inputs[i].name){
                    case 'age':
                    if(inputs[i].value.length > 0){
                       has_age = true;
                    }
                    case 'native_language':
                    if(inputs[i].value.length > 0){
                       has_native_language = true;
                    }
                    case 'primary_language':
                    if(inputs[i].value.length > 0){
                       has_primary_language = true;
                    }
                }
        }
    }
    if(! has_age){
       errors += "Age should be entered\n"; 
    } 
    if(! has_gender){
       errors += "Gender should be selected\n"; 
    }
    if(! has_native_language){
       errors += "Native language should be entered\n"; 
    }
    if(! has_primary_language){
       errors += "Primary language should be entered\n"; 
    }
    if(country.value == 0){ 
        errors += "Please select your country\n";
    
    }
    if (errors.length){
        alert(errors);
        return false;
    } else {
        return true;
    }
    
}