/*  
ajax form submit
*/
window.addEvent('domready', function() {
    var mySlide = new Fx.Slide($('log_res'),{duration: '1000'});
    
	$('myForm').addEvent('submit', function(e) {
//Empty the log and show the spinning indicator.
        
     //   $('log_res').empty();
        
        /*    $('inner_list_wrapper').addClass('ajax-loading');
          */
       // var log = $('log_res');
        var log = $('log_res').empty().addClass('ajax-loading');
	//	var log = $('log_res');
        //Prevents the default submit event from loading a new page.
	    
        e.stop();
		//Set the options of the form's Request handler. 
		//("this" refers to the $('myForm') element).
		this.set('send', {onComplete: function(response) { 
		mySlide.hide();
        log.removeClass('ajax-loading');
            
	    log.set('html', response);
        //    $('inner_list').set('src','tmp.php');
        mySlide.slideIn();

            
        }});
		//Send the form.
		this.send();
        
         
	});

    
});