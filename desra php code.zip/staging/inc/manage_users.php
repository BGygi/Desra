<?php
class ManageUsers {
    var $items_per_page = 3;
    var $item_count;
    var $page_count;
    public function __construct(){
        return (true); 
    }
    public function SetItemsPerPage($items_per_page){
        $this->items_per_page = $items_per_page;
    }
    public function GetItemCount(){
        return ($this->item_count);
    }
    public function GetPageCount(){
        return ($this->page_count);
    }
    public function GetPage($page_num = 1){
        $dbc = new GenericObjectCollection('users','User');

        $db = new DB;
        $sql = "SELECT `users`.`id` AS user_id,`accounts`.`id` AS account_id FROM users,accounts WHERE ";
        $sql .= "`accounts`.`user_id` = `users`.`id`";
        if(isset($_POST['term'])){
            $term = $_POST['term'];
            $sql = "SELECT `users`.`id` AS user_id,`accounts`.`id` AS account_id FROM users,accounts WHERE ";
            $sql .= "`accounts`.`user_id` = `users`.`id`";
            $sql .= " AND `users`.`username` LIKE ('".$term . "%"."')";
        }
        $stmt = $db->prepare($sql);
        $stmt->execute();
        while($row = $stmt->fetch()){
            $dbc->AddTuple($row['user_id']);
        }
        $dbc->SetPageSize($this->items_per_page);
        $dbc->PopulateObjectArray($page_num);
        $objArray= $dbc->RetrievePopulatedObjects();
        /*
        foreach($objArray as $obj){
            $user_id = $obj->GetId();
            $account = new Account();
            $account_ids = $account->FindByAttribute('user_id',$user_id);
            $account = new Account($account_ids[0]);
            $account->fields = $account->GetAllFields();
            $obj->account = $account;
        }
        */
        $this->page_num = $page_num;
        $this->item_count = $dbc->GetItemCount();
        $this->page_count = $dbc->GetNumPages();
        return $dbc;
    }
}



$user = new User;
$users = array();
$account = new Account;
$user_ids = $user->getAll();
$account_ids = $account->getAll();
$mu = new ManageUsers;
if($_POST['page_num']){
    $page_num = $_POST['page_num'];
} else {
    $page_num = 1;
}
$users = $mu->GetPage($page_num)->obj_array;
foreach($users as $user){
    $user_id = $user->GetId();
    $myAccount = new Account;
    $account_ids = $myAccount->FindByAttribute("user_id",$user_id);
    if(@count($account_ids)==1){
        $account_id = $account_ids[0];
        $myAccount = new Account($account_id);
        $myAccount->fields = $myAccount->GetAllFields();
        $user->account = $myAccount;
    }
}


$smarty->assign('users',$users);

$smarty->assign('mu',$mu);
$pages = array();
for($i=1;$i <= $mu->page_count;$i++){
    array_push($pages,$i);
}
$smarty->assign("pages",$pages);
$smarty->assign("post",$_POST);
?>
