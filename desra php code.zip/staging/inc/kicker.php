<?php
    if(! isset($_SESSION[auth]) ){
        header("location:error.php");
    }
?>
